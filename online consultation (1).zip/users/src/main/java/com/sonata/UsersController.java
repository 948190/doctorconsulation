package com.sonata;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sonata.model.Users;
import com.sonata.service.UserRepository;
import com.sonata.service.UserService;

@RestController
@RequestMapping("/users")
public class UsersController {
	
	@Autowired
	UserService us;
	
	@Autowired
	UserRepository ur;
	
	@PostMapping("/")
	public Users signup(@RequestBody Users u) {
		return ur.save(u);
	}
	
//	@GetMapping("/")
//	public List<Users> getAll(){
//		return us.getAll();
//	}
	
//	@GetMapping("/{id}")
//	public Users getById(@PathVariable int id){
//		return us.getId(id);
//	}
	
	@GetMapping("/{userName}/{password}")
	public Boolean login(@PathVariable String userName, @PathVariable String password)
	{
		return us.login(userName, password);
	}
	
	

}
