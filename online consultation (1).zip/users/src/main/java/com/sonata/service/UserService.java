package com.sonata.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sonata.model.Users;

@Service
public class UserService implements UserIntf {

	@Autowired
	UserRepository ur;
	
	@Override
	public Users signUp(Users u) {
		
		return ur.save(u);
	}
	
	

	@Override
	public Boolean login(String userName, String password) {
		Boolean flag=true;
		if(ur.findByUserNameAndPassword(userName, password).isEmpty())
			flag=false;
		return flag;
	}



	@Override
	public List<Users> getAll() {
		
		return ur.findAll();
	}



	@Override
	public Users getId(int id) {
		// TODO Auto-generated method stub
		return ur.findById(id).get();
	}

}
