package com.sonata.service;

import java.util.List;

import com.sonata.model.Users;

public interface UserIntf {
	
	public List<Users> getAll();
	public Users getId(int id);
	public Users signUp(Users u);
	public Boolean login(String userName,String password);

}
