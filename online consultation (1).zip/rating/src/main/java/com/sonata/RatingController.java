package com.sonata;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sonata.model.Rating;
import com.sonata.service.RatingService;

@RestController
@RequestMapping("/rating")
public class RatingController {
	
	@Autowired
	RatingService rs;
	
	@GetMapping("/{id}")
	public List<Rating> getRatings(@PathVariable int id){
		return rs.getRatings(id);
	}
	
	@PostMapping("/")
	public Rating postRating(@RequestBody Rating r){
		
		return rs.postRating(r);
	}
	

}
