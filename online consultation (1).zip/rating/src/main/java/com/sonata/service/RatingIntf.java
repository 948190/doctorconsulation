package com.sonata.service;

import java.util.List;

import com.sonata.model.Rating;

public interface RatingIntf {
	
	public Rating postRating(Rating r);
	public List<Rating> getRatings(int id);

}
