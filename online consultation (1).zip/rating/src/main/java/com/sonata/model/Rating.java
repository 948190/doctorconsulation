package com.sonata.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Rating {

	@Id
	private int pid;
	

	private int did;
	private int rating;
	private String comments;
	
	public Rating() {}
	public Rating(int pid, int did, int rating, String comments) {
		super();
		this.pid = pid;
		this.did = did;
		this.rating = rating;
		this.comments = comments;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public int getDid() {
		return did;
	}
	public void setDid(int did) {
		this.did = did;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	
	
	
	
}
