package com.sonata.model;

public enum Status{
	Available,
	Appointed,
	Completed,
	Cancelled
	
}