package com.sonata.model;

import java.util.List;

public class ConsultationList {
	
	List<Consultation> list;

	public List<Consultation> getList() {
		return list;
	}

	public void setList(List<Consultation> list) {
		this.list = list;
	}
	

}
