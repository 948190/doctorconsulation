package com.sonata;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.sonata.model.Consultation;
import com.sonata.model.ConsultationList;
import com.sonata.model.Doctor;
import com.sonata.model.DoctorsAvailable;
import com.sonata.model.DoctorsAvailableList;


@CrossOrigin(origins="http://localhost:4200/")
@RestController
public class ServiceCallsController {
	
	@Autowired
	RestTemplate rt;
	
	@GetMapping("/")
	public List<DoctorsAvailable> getDoctors() {
		
		ConsultationList slots= rt.getForObject("http://consultation-service/consultation/", ConsultationList.class);
		
		
		List<DoctorsAvailable> l= slots.getList().stream().map(slot->{
			Doctor d= rt.getForObject("http://doctor-service/doctor/"+slot.getDid(), Doctor.class);
			return new DoctorsAvailable(d.getDid(), d.getName(), d.getSpecialization(), slot.getDate(), slot.getTime());
		}).toList();
		
		return l;
	}
	
	@GetMapping("/{special}")
	public DoctorsAvailableList getDoctorsSpecial(@PathVariable String special) {
		
		ConsultationList slots= rt.getForObject("http://consultation-service/consultation/", ConsultationList.class);
		
		
		List<DoctorsAvailable> l= slots.getList().stream().map(slot->{
			Doctor d= rt.getForObject("http://doctor-service/doctor/"+slot.getDid(), Doctor.class);
			return new DoctorsAvailable(d.getDid(), d.getName(), d.getSpecialization(), slot.getDate(), slot.getTime());
		}).toList();
		DoctorsAvailableList dl=new DoctorsAvailableList();
		dl.setList(l.stream().filter(d-> d.getSpecial().equals(special)).toList());
		return dl;
		
	}
	
	

}
