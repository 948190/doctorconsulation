package com.sonata.model;

import java.util.List;

public class DoctorsAvailableList {
	
	private List<DoctorsAvailable> list;

	public List<DoctorsAvailable> getList() {
		return list;
	}

	public void setList(List<DoctorsAvailable> list) {
		this.list = list;
	}
	
	

}
