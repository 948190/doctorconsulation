package com.sonata.model;

import java.time.LocalDate;
import java.time.LocalTime;

public class DoctorsAvailable {
	
	private int did;
	private String dname;
	private String special;
	private LocalDate date;
	private LocalTime time;
	
	
	public DoctorsAvailable() {}
	public DoctorsAvailable(int did, String dname, String special, LocalDate date, LocalTime time) {
		super();
		this.did = did;
		this.dname = dname;
		this.special = special;
		this.date = date;
		this.time = time;
	}
	public int getDid() {
		return did;
	}
	public void setDid(int did) {
		this.did = did;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public String getSpecial() {
		return special;
	}
	public void setSpecial(String special) {
		this.special = special;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public LocalTime getTime() {
		return time;
	}
	public void setTime(LocalTime time) {
		this.time = time;
	}
	
	
	

}
