package com.sonata;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sonata.impl.PatientService;
import com.sonata.model.Patient;

@RestController
@RequestMapping("/patient")
public class PatientController {
	@Autowired
	PatientService ps;
	
	@PostMapping("/")
	public Patient add(@RequestBody Patient p) {
		return ps.addPatient(p);
	}
	
	@GetMapping("/")
	public List<Patient> get() {
		return ps.getAll();
	}
	
	@GetMapping("/{id}")
	public Patient get(@PathVariable int id) {
		return ps.getPatient(id);
	}
	
//	@GetMapping("/{s}")
//	public  String callJsp(@PathVariable String s ) {
//		return "hi"+s;
//	}
	
//	@GetMapping("/mobile/{id}")
//	public String getMobile(@PathVariable int id) {
//		return ps.sendSMS(id);
//	}
//	
//	@GetMapping("/Pname/{id}")
//	public String getPatientName(@PathVariable int id) {
//		return ps.getPatient(id).getName();
//	}
//	
//	@GetMapping("/Pdisease/{id}")
//	public String getPatientDisease(@PathVariable int id) {
//		return ps.getPatient(id).getDisease();
//	}
	

}
