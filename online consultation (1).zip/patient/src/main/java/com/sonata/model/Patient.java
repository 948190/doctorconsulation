package com.sonata.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class Patient {
	
	@Id
	@GeneratedValue
	private int p_id;
	private String name;
	private String address;
	private String mobile;
	private String email;
	private String disease;
	
	public Patient() {}
	public Patient( String name, String address, String mobile, String email, String disease) {
		super();
//		this.p_id = p_id;
		this.name = name;
		this.address = address;
		this.mobile = mobile;
		this.email = email;
		this.disease = disease;
	}
	public int getP_id() {
		return p_id;
	}
	public void setP_id(int p_id) {
		this.p_id = p_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getDisease() {
		return disease;
	}
	public void setDisease(String disease) {
		this.disease = disease;
	}
	
	

}
