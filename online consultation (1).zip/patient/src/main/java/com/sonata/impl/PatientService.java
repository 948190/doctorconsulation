package com.sonata.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sonata.intf.PatienIntf;
import com.sonata.intf.PatientRepository;
import com.sonata.model.Patient;

@Service
public class PatientService implements PatienIntf {

	@Autowired
	PatientRepository pr;
	
	@Override
	public Patient addPatient(Patient p) {
		return pr.save(p);
	}

	@Override
	public Patient getPatient(int id) {
		
		return pr.findById(id).get();
	}
	
	@Override
	public List<Patient> getAll() {
		
		return pr.findAll();
	}

	@Override
	public String sendSMS(int pid) {
		
		String mobile=pr.findById(pid).get().getMobile();
		return mobile;
	}
	
	

}
