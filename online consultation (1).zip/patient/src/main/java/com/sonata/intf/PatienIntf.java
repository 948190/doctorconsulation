package com.sonata.intf;

import java.util.List;

import com.sonata.model.Patient;

public interface PatienIntf {
	
	public Patient getPatient(int id);
	public List<Patient> getAll();
	public Patient addPatient(Patient p);
	public String sendSMS(int pid);

}
