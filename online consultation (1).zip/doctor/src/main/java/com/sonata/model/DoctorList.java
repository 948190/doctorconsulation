package com.sonata.model;

import java.util.List;

public class DoctorList {
	
	private List<Doctor> list;

	public List<Doctor> getList() {
		return list;
	}

	public void setList(List<Doctor> list) {
		this.list = list;
	}
	

}
